//
//  ViewController.swift
//  Light
//
//  Created by Ricky Titus on 9/24/19.
//  Copyright © 2019 Ricky Titus. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var lightOn = true
    var lightRed = true
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet var lightButton: UIButton!
    @IBOutlet var buttonLabel: UILabel!
    
    @IBAction func label(_ sender: Any){
        lightOn = !lightOn
        updateUI()
    }
    
    @IBAction func buttonPressed(_ sender: Any){
        lightOn = !lightOn
        updateUI()
    }
    func updateUI() {
        if lightOn {
            view.backgroundColor = .white
            updateLight()
        } else {
            view.backgroundColor = .black
        }
    }

    @IBOutlet var lightSwitch: UISwitch!
    
    @IBAction func switchPressed(_ sender: Any){
        lightRed = !lightRed
        updateLight()
    }
    func updateLight() {
        if lightOn{
            if lightRed {
                view.backgroundColor = .white
                buttonLabel.isHidden = false
            } else {
                view.backgroundColor = .red
                buttonLabel.isHidden = true
            }
        }
    }
}

